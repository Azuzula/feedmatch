# Feed Match Pro — Chrome doplněk

Zobrazuje vlastní skladové zásoby, nákupní a prodejní ceny přímo u produktů
na webech dodavatelů. Data bere z API Base44 aplikace, párování probíhá
lokálně v prohlížeči.

## Instalace (vývojový režim)

1. Otevřete `chrome://extensions`
2. Vpravo nahoře zapněte **Režim pro vývojáře**
3. Klikněte **Načíst rozbalené** a vyberte složku `feed-match-extension`
4. Klikněte na ikonu doplňku → **Nastavení** → vložte API klíč (`fsk_...`)
   a případně upravte adresu aplikace
5. **↻ Seznam domén** — stáhne sledované domény

## Jak to funguje

- **Seznam domén** se stahuje 1× denně (nebo ručně z popupu).
  Na nesledovaných doménách doplněk nedělá vůbec nic.
- **Feed produktů** se pro každou sledovanou doménu stahuje 1× denně
  při první návštěvě (nebo ručně tlačítkem **↻ Feed domény**).
- **Párování** (lokální, bez volání API na každý produkt):
  1. **EAN** — hledá se v textu elementu, data-atributech i URL,
     validuje se kontrolní číslicí → shoda 100 %
  2. **Kód výrobce** (`supplier_code`) — porovnává se normalizovaně
     (bez pomlček, velikosti písmen) → shoda 98 %
  3. **Fuzzy název** — Dice koeficient tokenů názvu na stránce vs.
     `tokens` + `alt_tokens` z feedu. Řeší jiné pořadí slov i diakritiku.
     Shody pod 35 % se nezobrazují, 35–60 % mají čárkovaný rámeček
     (nejistá shoda).
- **Infinite scroll / SPA** — MutationObserver hlídá nově přidané
  elementy a doskenuje je (debounce 600 ms). Změna URL bez reloadu se
  kontroluje každou vteřinu.
- **Badge** ukazuje: vlastní název produktu, % shody, nákupní cenu (N),
  prodejní cenu (P), skladovou zásobu. Zelený = skladem, červený = 0.
- **+ alias** — odešle název z webu dodavatele jako alternativní název
  produktu (`POST /functions/addAlternativeName`). Uloží se rovnou i do
  lokální cache, takže párování funguje okamžitě.

## Struktura

```
manifest.json          Manifest V3
background.js          Service worker: API, cache domén a feedů, zprávy
content/matcher.js     Párovací engine (normalizace, EAN, tokeny, Dice)
content/content.js     Sken DOM, detekce produktů, badge, observer
content/overlay.css    Styly badge (prefix .fmp-)
popup/…                Nastavení, stav, ruční akce
```

## Ladění

- Konzole **stránky** (F12) → logy content scriptu s prefixem `[FMP]`
- `chrome://extensions` → Feed Match Pro → **service worker** →
  konzole backgroundu
- Cache je v `chrome.storage.local` — v konzoli service workeru:
  `chrome.storage.local.get(null, console.log)`

## Známá omezení / další kroky

- Detekce produktových karet je heuristická; na exotických webech může
  být potřeba doladit `findProductContainers()` v `content/content.js`.
- Prahy fuzzy shody (0.35 / 0.60) jsou první nástřel — ladit podle praxe.
- `prompt()` pro alias je funkční, ale ošklivý; časem nahradit vlastním
  mini-dialogem.

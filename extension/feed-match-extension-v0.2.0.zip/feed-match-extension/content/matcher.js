/**
 * Feed Match Pro — párovací engine v2 (běží v content scriptu)
 * -------------------------------------------------------------
 * Priorita párování:
 *   1) EAN (validovaný checksumem)          → jistota 1.00
 *   2) supplier_code                        → jistota 0.98
 *   3) fuzzy skórování                      → viz níže
 *
 * Fuzzy skórování (v2):
 *   - MATERIÁL je tvrdá brána: PLA ≠ PETG ≠ ABS…, a stejně tak
 *     PLA ≠ PLA+ ≠ Silk PLA ≠ PLA-CF. Neshoda = kandidát vyřazen.
 *   - BARVY jsou měkký signál: úplně jiná barva = vyřazení,
 *     částečná shoda ("transparent green" vs jen "transparent")
 *     = penalizace + příznak nejistoty.
 *   - Skóre = 0.45·Dice + 0.55·pokrytí tokenů stránky produktem
 *     (+ bonus za explicitně shodný materiál na obou stranách).
 *   - MARGIN test: pokud je druhý nejlepší kandidát (jiný produkt)
 *     těsně za nejlepším, shoda je nejednoznačná → zahodit / unsure.
 *     Tohle řeší "stejná položka pro 4 různé barvy".
 *
 * Ladění: window.__fmpDebug = true v konzoli stránky → engine loguje
 * i zamítnuté a těsné kandidáty s důvodem.
 */

"use strict";

/* ------------------------------------------------- normalizace textu */

const FMP_STOPWORDS = new Set([
  // čeština
  "a", "i", "s", "se", "na", "do", "pro", "od", "za", "ks", "kus", "kusu", "baleni",
  "nova", "novy", "nove", "akce", "sleva", "skladem",
  // angličtina
  "the", "and", "for", "with", "of", "new", "pcs", "pack", "set",
]);

function fmpNormalize(str) {
  return String(str || "")
    .toLowerCase()
    .replace(/\+/g, " plus ")          // "PLA+" → "pla plus" (jinak se + zahodí!)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")   // odstranění diakritiky
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function fmpTokenize(str) {
  const words = fmpNormalize(str).split(/\s+/).filter(Boolean);
  const out = new Set();
  for (let i = 0; i < words.length; i++) {
    const w = words[i];

    // "pet" + "g" → jeden token "petg" (řeší zápis PET-G)
    if (w === "pet" && words[i + 1] === "g") {
      out.add("petg");
      i++;
      continue;
    }

    if (FMP_STOPWORDS.has(w)) continue;
    if (w.length >= 2 || /\d/.test(w)) out.add(w);

    // "1" + "kg" → přidej i "1kg" (rozdíly v zápisu jednotek)
    if (/^\d+([.,]\d+)?$/.test(w) && i + 1 < words.length && /^[a-z]{1,4}$/.test(words[i + 1])) {
      out.add(w + words[i + 1]);
    }
  }
  return out;
}

/** Dice koeficient dvou množin tokenů: 2·|A∩B| / (|A|+|B|) */
function fmpDice(setA, setB) {
  if (!setA.size || !setB.size) return 0;
  let inter = 0;
  const [small, big] = setA.size <= setB.size ? [setA, setB] : [setB, setA];
  for (const t of small) if (big.has(t)) inter++;
  return (2 * inter) / (setA.size + setB.size);
}

/** Podíl tokenů z A pokrytých množinou B: |A∩B| / |A| */
function fmpCoverage(setA, setB) {
  if (!setA.size) return 0;
  let inter = 0;
  for (const t of setA) if (setB.has(t)) inter++;
  return inter / setA.size;
}

/* --------------------------------------------------------- materiály */

// základní materiály — tvrdá brána
const FMP_MATERIAL_BASES = [
  ["petg", /\bpet\s?g\b|\bpetg\b/],
  ["pla", /\bpla\b/],
  ["abs", /\babs\b/],
  ["asa", /\basa\b/],
  ["tpu", /\btpu\b|\btpe\b|\bflex\b/],
  ["pc", /\bpc\b|\bpolycarbonate\b|\bpolykarbonat\b/],
  ["pa", /\bpa\b|\bnylon\b/],
  ["pva", /\bpva\b/],
  ["hips", /\bhips\b/],
  ["pctg", /\bpctg\b/],
  ["cpe", /\bcpe\b/],
  ["pp", /\bpp\b|\bpolypropylen\w*\b/],
];

// modifikátory materiálu — také tvrdá brána (PLA ≠ PLA+ ≠ Silk PLA ≠ PLA-CF)
const FMP_MATERIAL_MODS = [
  ["plus", /\bplus\b/],   // vzniká z "+" v fmpNormalize
  ["silk", /\bsilk\b/],
  ["cf", /\bcf\b|\bcarbon\b/],
  ["gf", /\bgf\b|\bglassfib\w*\b/],
  ["wood", /\bwood\b/],
];

/**
 * Vytáhne materiál z normalizovaného textu.
 * @returns {{ base: string|null, mods: string }} mods = seřazený klíč, např. "cf+plus"
 */
function fmpExtractMaterial(normText) {
  const s = " " + normText + " ";
  let base = null;
  let bestPos = Infinity;
  for (const [name, re] of FMP_MATERIAL_BASES) {
    const m = s.match(re);
    if (m && m.index < bestPos) { base = name; bestPos = m.index; }
  }
  const mods = [];
  if (base) {
    for (const [name, re] of FMP_MATERIAL_MODS) {
      if (re.test(s)) mods.push(name);
    }
  }
  return { base, mods: mods.sort().join("+") };
}

/* ------------------------------------------------------------- barvy */

const FMP_COLORS = new Set([
  // en
  "black", "white", "gray", "grey", "red", "green", "blue", "yellow", "orange",
  "purple", "violet", "pink", "brown", "beige", "gold", "silver", "cyan",
  "magenta", "turquoise", "olive", "coffee", "mint", "ivory", "navy", "lime",
  "transparent", "clear", "natural", "grass",
  // cs (bez diakritiky, po normalizaci)
  "cerna", "cerny", "bila", "bily", "seda", "sedy", "cervena", "cerveny",
  "zelena", "zeleny", "modra", "modry", "zluta", "zluty", "oranzova", "oranzovy",
  "fialova", "fialovy", "ruzova", "ruzovy", "hneda", "hnedy", "zlata", "zlaty",
  "stribrna", "stribrny", "pruhledna", "pruhledny", "cira", "ciry", "prirodni",
]);

function fmpColorsOf(tokenSet) {
  const out = new Set();
  for (const t of tokenSet) if (FMP_COLORS.has(t)) out.add(t);
  return out;
}

/* ------------------------------------------------------ EAN validace */

function fmpValidEan(code) {
  if (!/^\d{8}$|^\d{13}$/.test(code)) return false;
  const digits = code.split("").map(Number);
  const check = digits.pop();
  let sum = 0;
  digits.reverse().forEach((d, i) => { sum += d * (i % 2 === 0 ? 3 : 1); });
  return (10 - (sum % 10)) % 10 === check;
}

function fmpExtractEans(text) {
  const found = new Set();
  const re = /\d{8,14}/g;
  let m;
  while ((m = re.exec(text)) !== null) {
    const s = m[0];
    if (s.length === 13 || s.length === 8) {
      if (fmpValidEan(s)) found.add(s);
    } else if (s.length > 13) {
      for (let i = 0; i + 13 <= s.length; i++) {
        const sub = s.slice(i, i + 13);
        if (fmpValidEan(sub)) found.add(sub);
      }
    }
  }
  return [...found];
}

/* ----------------------------------------------------- kódy výrobce */

function fmpNormalizeCode(code) {
  return String(code || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
}

function fmpExtractCodeCandidates(text, url) {
  const out = new Set();
  const push = (raw) => {
    const c = fmpNormalizeCode(raw);
    if (c.length >= 4 && c.length <= 40) out.add(c);
  };
  for (const w of String(text || "").split(/\s+/)) push(w);
  try {
    const u = new URL(url, location.href);
    u.pathname.split("/").forEach(push);
    u.searchParams.forEach((v) => push(v));
  } catch (_) { /* neplatná URL — ignorovat */ }
  return out;
}

/* --------------------------------------------------------- FmpIndex */

// prahy — laděno podle testu na kategoriích PLA/PETG
const FMP_SHOW_THRESHOLD = 0.50;   // pod tím shodu vůbec neukazovat
const FMP_SURE_THRESHOLD = 0.72;   // pod tím vždy "nejistá shoda"
const FMP_MARGIN_REJECT  = 0.05;   // náskok < 5 p.b. na druhého → zahodit (generická shoda)
const FMP_MARGIN_UNSURE  = 0.12;   // náskok < 12 p.b. → nejistá shoda
const FMP_MATERIAL_BONUS = 0.12;   // oba explicitně stejný materiál
const FMP_ONESIDE_MAT_PENALTY = 0.08; // materiál jen na jedné straně
const FMP_COLOR_MISMATCH_PENALTY = 0.18; // za každou nepokrytou barvu

class FmpIndex {
  constructor(products) {
    this.products = products;
    this.eanMap = new Map();
    this.codeMap = new Map();
    this.tokenIndex = new Map();  // token -> Set(productIdx)
    this.variants = [];           // idx -> [{tokens:Set, material, colors:Set}, ...]

    products.forEach((p, idx) => {
      if (p.ean) this.eanMap.set(String(p.ean).trim(), p);
      if (p.supplier_code) this.codeMap.set(fmpNormalizeCode(p.supplier_code), p);

      // Tokeny přepočítáváme vždy vlastní tokenizací (spojenou z feedu),
      // aby prošly stejnou úpravou jako text stránky (pla+ → plus, pet-g → petg).
      const mainSrc = (Array.isArray(p.tokens) && p.tokens.length)
        ? p.tokens.join(" ")
        : (p.name || "");
      const altSrc = (Array.isArray(p.alt_tokens) && p.alt_tokens.length)
        ? p.alt_tokens.join(" ")
        : (p.alternative_names || []).join(" ");

      const vars = [];
      const mainTokens = fmpTokenize(mainSrc);
      if (mainTokens.size) {
        vars.push({
          tokens: mainTokens,
          material: fmpExtractMaterial(fmpNormalize(p.name || mainSrc)),
          colors: fmpColorsOf(mainTokens),
        });
      }
      const altTokens = fmpTokenize(altSrc);
      if (altTokens.size) {
        vars.push({
          tokens: altTokens,
          material: fmpExtractMaterial([...altTokens].join(" ")),
          colors: fmpColorsOf(altTokens),
        });
      }
      this.variants[idx] = vars;

      const all = new Set();
      vars.forEach((v) => v.tokens.forEach((t) => all.add(t)));
      for (const t of all) {
        if (!this.tokenIndex.has(t)) this.tokenIndex.set(t, new Set());
        this.tokenIndex.get(t).add(idx);
      }
    });
  }

  /**
   * Skóre jedné varianty produktu proti názvu na stránce.
   * @returns {null | {score:number, unsure:boolean, reason?:string}}
   */
  _scoreVariant(pageTokens, pageMat, pageColors, variant) {
    const prodMat = variant.material;

    // ---- tvrdá brána: materiál
    if (pageMat.base && prodMat.base) {
      if (pageMat.base !== prodMat.base) {
        return { score: -1, unsure: false, reason: `materiál ${pageMat.base} ≠ ${prodMat.base}` };
      }
      if (pageMat.mods !== prodMat.mods) {
        return {
          score: -1, unsure: false,
          reason: `varianta materiálu ${pageMat.base}${pageMat.mods ? "-" + pageMat.mods : ""} ≠ ${prodMat.base}${prodMat.mods ? "-" + prodMat.mods : ""}`,
        };
      }
    }

    // ---- barvy
    const prodColors = variant.colors;
    let colorPenalty = 0;
    let colorUnsure = false;
    if (pageColors.size && prodColors.size) {
      let common = 0;
      for (const c of pageColors) if (prodColors.has(c)) common++;
      // gray/grey a en/cs synonyma neřešíme párově — stačí aspoň jeden průnik
      if (common === 0) {
        return { score: -1, unsure: false, reason: "jiná barva" };
      }
      const missing = pageColors.size - common;          // barvy na stránce, které produkt nemá
      const extra = prodColors.size - common;            // barvy produktu, které stránka nemá
      if (missing + extra > 0) {
        colorPenalty = FMP_COLOR_MISMATCH_PENALTY * (missing + extra);
        colorUnsure = true;
      }
    }

    // ---- textová podobnost: Dice + pokrytí stránky
    const dice = fmpDice(pageTokens, variant.tokens);
    const coverage = fmpCoverage(pageTokens, variant.tokens);
    let score = 0.45 * dice + 0.55 * coverage;

    // ---- materiálové bonusy/penalizace
    let unsure = colorUnsure;
    if (pageMat.base && prodMat.base) {
      score = Math.min(0.97, score + FMP_MATERIAL_BONUS); // shodný materiál potvrzen oběma stranami
    } else if (pageMat.base || prodMat.base) {
      score -= FMP_ONESIDE_MAT_PENALTY; // materiál známe jen z jedné strany → nejistota
      unsure = true;
    }

    score -= colorPenalty;
    return { score, unsure };
  }

  /**
   * @param {string} fullText   celý text produktového elementu
   * @param {string} url        odkaz na produkt (href)
   * @param {string} nameText   nejpravděpodobnější název na stránce
   * @returns {null | {product, score, method, unsure, matchedName}}
   */
  match(fullText, url, nameText) {
    const haystack = fullText + " " + url;
    const debug = !!window.__fmpDebug;

    // 1) EAN — nejsilnější signál
    for (const ean of fmpExtractEans(haystack)) {
      const p = this.eanMap.get(ean);
      if (p) return { product: p, score: 1, method: "ean", unsure: false, matchedName: nameText };
    }

    // 2) kód výrobce
    for (const c of fmpExtractCodeCandidates(fullText, url)) {
      const p = this.codeMap.get(c);
      if (p) return { product: p, score: 0.98, method: "code", unsure: false, matchedName: nameText };
    }

    // 3) fuzzy
    const pageTokens = fmpTokenize(nameText);
    if (!pageTokens.size) return null;
    const pageNorm = fmpNormalize(nameText);
    const pageMat = fmpExtractMaterial(pageNorm);
    const pageColors = fmpColorsOf(pageTokens);

    // shortlist přes invertovaný index
    const hits = new Map(); // idx -> počet společných tokenů
    for (const t of pageTokens) {
      const ids = this.tokenIndex.get(t);
      if (!ids) continue;
      for (const idx of ids) hits.set(idx, (hits.get(idx) || 0) + 1);
    }
    if (!hits.size) {
      if (debug) console.debug("[FMP] bez kandidáta:", nameText);
      return null;
    }

    let best = null;    // { idx, score, unsure }
    let second = null;  // nejlepší JINÝ produkt
    const rejects = [];

    for (const [idx, common] of hits) {
      if (common < 2 && pageTokens.size > 2) continue;
      let vBest = null;
      for (const variant of this.variants[idx]) {
        const r = this._scoreVariant(pageTokens, pageMat, pageColors, variant);
        if (r.score < 0) { if (debug) rejects.push({ idx, reason: r.reason }); continue; }
        if (!vBest || r.score > vBest.score) vBest = r;
      }
      if (!vBest) continue;

      const entry = { idx, score: vBest.score, unsure: vBest.unsure };
      if (!best || entry.score > best.score) {
        if (best && best.idx !== entry.idx) second = best;
        best = entry;
      } else if (best.idx !== entry.idx && (!second || entry.score > second.score)) {
        second = entry;
      }
    }

    if (debug && rejects.length) {
      console.debug(
        "[FMP] zamítnutí pro:", nameText,
        rejects.slice(0, 5).map((r) => `${this.products[r.idx].name} (${r.reason})`)
      );
    }

    if (!best || best.score < FMP_SHOW_THRESHOLD) {
      if (debug && best) {
        console.debug(`[FMP] pod prahem (${best.score.toFixed(2)}):`, nameText,
          "→", this.products[best.idx].name);
      }
      return null;
    }

    // MARGIN test — řeší "stejná generická položka pro víc různých produktů"
    let unsure = best.unsure || best.score < FMP_SURE_THRESHOLD;
    if (second) {
      const margin = best.score - second.score;
      if (margin < FMP_MARGIN_REJECT) {
        if (debug) {
          console.debug(`[FMP] nejednoznačné (margin ${margin.toFixed(2)}):`, nameText,
            "→", this.products[best.idx].name, "vs", this.products[second.idx].name);
        }
        return null;
      }
      if (margin < FMP_MARGIN_UNSURE) unsure = true;
    }

    return {
      product: this.products[best.idx],
      score: Math.max(0, Math.min(best.score, 0.97)),
      method: "fuzzy",
      unsure,
      matchedName: nameText,
    };
  }
}

// export do globálního scope content scriptu
window.FMP = { FmpIndex, fmpTokenize, fmpNormalize, fmpExtractEans, fmpExtractMaterial };

/**
 * Feed Match Pro — content script
 * -------------------------------
 * 1. Zeptá se backgroundu, jestli je aktuální doména sledovaná.
 * 2. Pokud ano, dostane feed a postaví párovací index.
 * 3. Heuristicky najde produktové elementy v DOM, spáruje je s feedem
 *    a vloží k nim badge s vlastními cenami a skladem.
 * 4. MutationObserver hlídá donačítání dalších produktů (infinite scroll).
 */

"use strict";

(() => {
  if (window.__fmpLoaded) return; // ochrana proti dvojí injekci
  window.__fmpLoaded = true;

  let fmpIndex = null;
  let feedLabel = "";
  let scanTimer = null;
  let matchedCount = 0;

  const PRICE_RE = /\d[\d\s\u00a0.,]*\s?(kč|czk|eur|€|\$|usd)/i;
  const czk = new Intl.NumberFormat("cs-CZ", { maximumFractionDigits: 2 });

  /* ------------------------------------------------------------ start */

  async function init(force = false) {
    const resp = await chrome.runtime.sendMessage({
      type: "GET_FEED",
      hostname: location.hostname,
      force,
    }).catch(() => null);

    if (!resp || !resp.tracked || !resp.products?.length) return;

    fmpIndex = new window.FMP.FmpIndex(resp.products);
    feedLabel = resp.label || resp.domain;
    matchedCount = 0;

    // při ručním refreshi smaž staré badge a resetuj flagy
    document.querySelectorAll(".fmp-badge").forEach((el) => el.remove());
    document.querySelectorAll("[data-fmp-done]").forEach((el) => delete el.dataset.fmpDone);

    scanPage();
    startObserver();
  }

  /* --------------------------------------------- detekce produktových
     elementů: od odkazů šplháme k nejmenšímu předku, který vypadá jako
     "karta produktu" (obsahuje cenu nebo obrázek a není moc velký). */

  function findProductContainers(root) {
    const containers = new Set();
    const anchors = root.querySelectorAll ? root.querySelectorAll("a[href]") : [];

    for (const a of anchors) {
      const text = (a.textContent || "").trim();
      const hasImg = !!a.querySelector("img");
      if (text.length < 8 && !hasImg) continue; // navigační odkazy apod.

      let node = a;
      let candidate = null;
      for (let depth = 0; depth < 8 && node && node !== document.body; depth++) {
        node = node.parentElement;
        if (!node) break;

        const links = node.querySelectorAll("a[href]");
        const distinctHrefs = new Set([...links].map((l) => l.getAttribute("href")));
        if (distinctHrefs.size > 4) break; // už jsme moc vysoko (celý grid/stránka)

        const t = node.textContent || "";
        if (PRICE_RE.test(t) || node.querySelector("img")) {
          candidate = node;
          // pokud element vypadá jako karta (li/article/product class), bereme hned
          if (
            node.matches("li, article") ||
            /product|item|card|tile/i.test(node.className || "")
          ) break;
        }
      }
      if (candidate && !candidate.dataset.fmpDone) containers.add(candidate);
    }

    // detail produktu (žádný grid): H1 + cena na stránce
    const h1 = document.querySelector("h1");
    if (h1 && !document.querySelector(".fmp-badge--detail") && PRICE_RE.test(document.body.textContent || "")) {
      containers.add(h1);
    }

    return [...containers];
  }

  /** Nejpravděpodobnější název produktu uvnitř kontejneru. */
  function extractName(container) {
    if (container.tagName === "H1") return container.textContent.trim();

    const heading = container.querySelector("h1, h2, h3, h4, [class*='title'], [class*='name']");
    if (heading && heading.textContent.trim().length >= 5) return heading.textContent.trim();

    // nejdelší text odkazu
    let best = "";
    for (const a of container.querySelectorAll("a[href]")) {
      const t = (a.textContent || "").trim();
      if (t.length > best.length) best = t;
    }
    if (best.length >= 5) return best;

    const img = container.querySelector("img[alt]");
    return img ? img.alt.trim() : "";
  }

  function extractUrl(container) {
    if (container.tagName === "H1") return location.href;
    const a = container.querySelector("a[href]");
    return a ? a.href : location.href;
  }

  /* ------------------------------------------------------------- scan */

  function scanPage(root = document.body) {
    if (!fmpIndex) return;

    for (const el of findProductContainers(root)) {
      el.dataset.fmpDone = "1";

      const name = extractName(el);
      if (!name) continue;

      // data-* atributy často nesou EAN/kód — přibalíme je k textu
      const dataAttrs = [...el.querySelectorAll("[data-ean], [data-code], [data-sku], [data-product-code]")]
        .flatMap((n) => Object.values(n.dataset)).join(" ");
      const fullText = (el.textContent || "") + " " + dataAttrs;
      const url = extractUrl(el);

      const result = fmpIndex.match(fullText, url, name);
      if (result) {
        injectBadge(el, result);
        matchedCount++;
      }
    }
    reportMatches();
  }

  function reportMatches() {
    chrome.runtime.sendMessage({ type: "PAGE_MATCHES", count: matchedCount }).catch(() => {});
  }

  /* ------------------------------------------------------------ badge */

  function fmtPrice(v) {
    return (v === null || v === undefined || v === "") ? "—" : czk.format(v) + " Kč";
  }

  function injectBadge(container, result) {
    const p = result.product;
    const pct = Math.round(result.score * 100);
    const stock = Number(p.stock_qty ?? 0);
    const unit = p.stock_unit || "ks";

    const badge = document.createElement("div");
    badge.className = "fmp-badge"
      + (stock > 0 ? " fmp-instock" : " fmp-nostock")
      + (result.unsure ? " fmp-unsure" : "")
      + (container.tagName === "H1" ? " fmp-badge--detail" : "");

    const methodLabel = { ean: "EAN", code: "kód", fuzzy: "název" }[result.method];
    const scoreTitle = "Shoda přes: " + methodLabel
      + (result.unsure ? " (nejistá — ověřte, případně potvrďte přes + alias)" : "");

    badge.innerHTML = `
      <div class="fmp-row fmp-head">
        <span class="fmp-name" title="${escapeHtml(p.name)}">${escapeHtml(p.name)}</span>
        <span class="fmp-score" title="${scoreTitle}">${pct}&nbsp;%${result.unsure ? "&nbsp;?" : ""}</span>
      </div>
      <div class="fmp-row fmp-data">
        <span title="Nákupní cena">N: <b>${fmtPrice(p.purchase_price)}</b></span>
        <span title="Prodejní cena">P: <b>${fmtPrice(p.sale_price)}</b></span>
        <span class="fmp-stock" title="Skladem">${stock > 0 ? "✓" : "✗"} ${czk.format(stock)}&nbsp;${escapeHtml(unit)}</span>
      </div>
      <button class="fmp-alias" type="button" title="Odeslat název z této stránky jako alias pro lepší párování">+ alias</button>
    `;

    badge.querySelector(".fmp-alias").addEventListener("click", async (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      const suggested = result.matchedName || "";
      const name = prompt(
        `Přidat alternativní název pro:\n„${p.name}“\n\nUpravte podle potřeby:`,
        suggested
      );
      if (!name || !name.trim()) return;

      const btn = ev.currentTarget;
      btn.disabled = true;
      btn.textContent = "…";
      const resp = await chrome.runtime.sendMessage({
        type: "ADD_ALT_NAME",
        productId: p.id,
        name: name.trim(),
        hostname: location.hostname,
      }).catch(() => null);

      if (resp && resp.ok) {
        btn.textContent = "✓ uloženo";
        btn.classList.add("fmp-alias--ok");
      } else {
        btn.textContent = "chyba";
        btn.disabled = false;
        console.warn("[FMP] addAlternativeName:", resp && resp.error);
      }
    });

    // u H1 (detail produktu) vkládáme za nadpis, jinak na konec karty
    if (container.tagName === "H1") {
      container.insertAdjacentElement("afterend", badge);
    } else {
      container.appendChild(badge);
    }
  }

  function escapeHtml(s) {
    return String(s || "").replace(/[&<>"']/g, (c) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
    }[c]));
  }

  /* ---------------------------------- infinite scroll / SPA navigace */

  function startObserver() {
    const observer = new MutationObserver((mutations) => {
      // ignoruj mutace způsobené našimi badge
      const relevant = mutations.some((m) =>
        [...m.addedNodes].some(
          (n) => n.nodeType === 1 && !n.classList?.contains("fmp-badge") && !n.closest?.(".fmp-badge")
        )
      );
      if (!relevant) return;
      clearTimeout(scanTimer);
      scanTimer = setTimeout(() => scanPage(), 600);
    });
    observer.observe(document.body, { childList: true, subtree: true });

    // SPA: změna URL bez reloadu
    let lastUrl = location.href;
    setInterval(() => {
      if (location.href !== lastUrl) {
        lastUrl = location.href;
        clearTimeout(scanTimer);
        scanTimer = setTimeout(() => scanPage(), 800);
      }
    }, 1000);
  }

  /* --------------------------------------------------- zprávy z popupu */

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "RESCAN") {
      init(!!msg.forceFeed).then(() => sendResponse({ ok: true, matches: matchedCount }));
      return true;
    }
    if (msg.type === "GET_PAGE_MATCHES") {
      sendResponse({ matches: matchedCount, active: !!fmpIndex });
    }
  });

  init();
})();

/** Feed Match Pro — popup */

"use strict";

const $ = (id) => document.getElementById(id);

let currentTab = null;
let currentHostname = null;

function showMsg(text, cls = "") {
  const f = $("msg");
  f.textContent = text;
  f.className = cls;
  if (text) setTimeout(() => { f.textContent = ""; f.className = ""; }, 4000);
}

function fmtTime(ts) {
  if (!ts) return "—";
  return new Date(ts).toLocaleString("cs-CZ", {
    day: "numeric", month: "numeric", hour: "2-digit", minute: "2-digit",
  });
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  currentTab = tab || null;
  try {
    currentHostname = tab?.url ? new URL(tab.url).hostname : null;
  } catch { currentHostname = null; }
}

async function refreshStatus() {
  const st = await chrome.runtime.sendMessage({
    type: "GET_STATUS",
    hostname: currentHostname,
  }).catch(() => null);

  const dot = $("dot");
  const text = $("statusText");
  const detail = $("statusDetail");

  if (!st || st.error) {
    dot.className = "dot err";
    text.textContent = "Chyba komunikace";
    detail.textContent = st?.error || "";
    return;
  }

  $("enabled").checked = st.enabled;

  if (!st.hasApiKey) {
    dot.className = "dot err";
    text.textContent = "Chybí API klíč";
    detail.textContent = "Vyplňte ho v Nastavení níže.";
    return;
  }

  if (!st.enabled) {
    dot.className = "dot";
    text.textContent = "Doplněk je vypnutý";
    detail.textContent = "";
    return;
  }

  if (st.tracked) {
    dot.className = "dot ok";
    text.textContent = `Sledovaná doména: ${st.domainLabel}`;
    let lines = `Domén celkem: ${st.domainsCount} (staženo ${fmtTime(st.domainsFetchedAt)})`;
    lines += st.feed
      ? `\nFeed: ${st.feed.count} produktů (staženo ${fmtTime(st.feed.fetchedAt)})`
      : "\nFeed: zatím nestažen";
    detail.textContent = lines;

    // dotaz na content script — kolik je shod na stránce
    if (currentTab?.id) {
      chrome.tabs.sendMessage(currentTab.id, { type: "GET_PAGE_MATCHES" })
        .then((r) => {
          if (r) detail.textContent += `\nShody na stránce: ${r.matches}`;
        })
        .catch(() => {});
    }
  } else {
    dot.className = "dot";
    text.textContent = "Tato doména se nesleduje";
    detail.textContent = `Domén celkem: ${st.domainsCount} (staženo ${fmtTime(st.domainsFetchedAt)})`;
  }
}

/* -------------------------------------------------------------- akce */

$("btnRefreshDomains").addEventListener("click", async (e) => {
  e.currentTarget.disabled = true;
  const r = await chrome.runtime.sendMessage({ type: "REFRESH_DOMAINS" }).catch(() => null);
  e.currentTarget.disabled = false;
  if (r?.ok) { showMsg(`Staženo ${r.count} domén.`, "ok"); refreshStatus(); }
  else showMsg("Chyba: " + (r?.error || "neznámá"), "err");
});

$("btnRefreshFeed").addEventListener("click", async (e) => {
  if (!currentHostname) return showMsg("Nelze zjistit doménu tohoto tabu.", "err");
  e.currentTarget.disabled = true;
  const r = await chrome.runtime.sendMessage({
    type: "REFRESH_FEED",
    hostname: currentHostname,
  }).catch(() => null);
  e.currentTarget.disabled = false;
  if (r?.ok) {
    showMsg(`Feed obnoven (${r.count} produktů).`, "ok");
    // rovnou přeskenovat stránku s novým feedem
    if (currentTab?.id) chrome.tabs.sendMessage(currentTab.id, { type: "RESCAN" }).catch(() => {});
    refreshStatus();
  } else {
    showMsg("Chyba: " + (r?.error || "neznámá"), "err");
  }
});

$("btnRescan").addEventListener("click", async () => {
  if (!currentTab?.id) return;
  const r = await chrome.tabs.sendMessage(currentTab.id, { type: "RESCAN" }).catch(() => null);
  if (r?.ok) { showMsg(`Hotovo, shod: ${r.matches}.`, "ok"); refreshStatus(); }
  else showMsg("Na této stránce content script neběží (zkuste reload stránky).", "err");
});

$("enabled").addEventListener("change", async (e) => {
  await chrome.runtime.sendMessage({ type: "SET_SETTINGS", enabled: e.target.checked });
  refreshStatus();
});

$("btnSave").addEventListener("click", async () => {
  const apiKey = $("apiKey").value.trim();
  const appBase = $("appBase").value.trim();
  const patch = { type: "SET_SETTINGS" };
  if (apiKey) patch.apiKey = apiKey;
  if (appBase) patch.appBase = appBase;
  await chrome.runtime.sendMessage(patch);
  showMsg("Uloženo.", "ok");
  refreshStatus();
});

/* --------------------------------------------------------------- init */

(async () => {
  const s = await chrome.storage.local.get(["apiKey", "appBase"]);
  if (s.apiKey) $("apiKey").value = s.apiKey;
  if (s.appBase) $("appBase").value = s.appBase;
  await getActiveTab();
  await refreshStatus();
})();

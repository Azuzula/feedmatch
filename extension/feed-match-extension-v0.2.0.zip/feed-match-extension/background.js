/**
 * Feed Match Pro — background service worker
 * ------------------------------------------
 * Stará se o:
 *  - komunikaci s API (Bearer token = API klíč uživatele)
 *  - cache seznamu domén (platnost: do konce dne, nebo ruční refresh)
 *  - cache feedů per doména (platnost: do konce dne, nebo ruční refresh)
 *  - přeposílání dat content scriptu a popupu
 */

const DEFAULT_APP_BASE = "https://feed-match-pro.base44.app";

/* ---------------------------------------------------------- utils */

function localDayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

async function getSettings() {
  const s = await chrome.storage.local.get(["apiKey", "appBase", "enabled"]);
  return {
    apiKey: s.apiKey || "",
    appBase: (s.appBase || DEFAULT_APP_BASE).replace(/\/+$/, ""),
    enabled: s.enabled !== false, // default zapnuto
  };
}

async function apiFetch(path, options = {}) {
  const { apiKey, appBase } = await getSettings();
  if (!apiKey) throw new Error("NO_API_KEY");

  const resp = await fetch(appBase + path, {
    ...options,
    headers: {
      "Authorization": "Bearer " + apiKey,
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
  });

  if (!resp.ok) {
    const body = await resp.text().catch(() => "");
    throw new Error(`API ${resp.status}: ${body.slice(0, 200)}`);
  }
  return resp.json();
}

/* --------------------------------------- normalizace (kopie z matcher.js,
   service worker nesdílí soubory s content scriptem) */

function fmpNormalize(str) {
  return String(str || "")
    .toLowerCase()
    .replace(/\+/g, " plus ")          // "PLA+" → "pla plus"
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function fmpTokenize(str) {
  const words = fmpNormalize(str).split(/\s+/).filter(Boolean);
  const out = new Set();
  for (let i = 0; i < words.length; i++) {
    const w = words[i];
    if (w === "pet" && words[i + 1] === "g") { out.add("petg"); i++; continue; }
    if (w.length >= 2 || /\d/.test(w)) out.add(w);
    // spoj číslo + jednotku: "1" + "kg" -> "1kg"
    if (/^\d+([.,]\d+)?$/.test(w) && i + 1 < words.length && /^[a-z]{1,4}$/.test(words[i + 1])) {
      out.add(w + words[i + 1]);
    }
  }
  return [...out];
}

/* ---------------------------------------------------------- domény */

async function ensureDomains(force = false) {
  const { domainsCache } = await chrome.storage.local.get("domainsCache");
  const today = localDayKey();

  if (!force && domainsCache && domainsCache.day === today) {
    return domainsCache.domains;
  }

  const data = await apiFetch("/functions/getDomainsForExtension");
  const domains = Array.isArray(data.domains) ? data.domains : [];
  await chrome.storage.local.set({
    domainsCache: { day: today, fetchedAt: Date.now(), domains },
  });
  return domains;
}

/** Najde záznam domény pro hostname (řeší i www. a subdomény). */
function findDomainEntry(domains, hostname) {
  const h = String(hostname || "").toLowerCase().replace(/^www\./, "");
  return domains.find((d) => {
    const dd = String(d.domain || "").toLowerCase().replace(/^www\./, "");
    return h === dd || h.endsWith("." + dd);
  }) || null;
}

/* ---------------------------------------------------------- feedy */

function feedKey(domain) {
  return "feed:" + domain;
}

async function ensureFeed(domainEntry, force = false) {
  const key = feedKey(domainEntry.domain);
  const stored = await chrome.storage.local.get(key);
  const cached = stored[key];
  const today = localDayKey();

  if (!force && cached && cached.day === today) {
    return cached;
  }

  const data = await apiFetch(
    `/functions/getProductsForExtension?domain=${encodeURIComponent(domainEntry.domain)}&limit=5000`
  );

  const feed = {
    day: today,
    fetchedAt: Date.now(),
    cached_at: data.cached_at || null,
    products: Array.isArray(data.products) ? data.products : [],
  };
  await chrome.storage.local.set({ [key]: feed });
  return feed;
}

/* ------------------------------------------------- alternativní názvy */

async function addAlternativeName(productId, name, hostname) {
  const result = await apiFetch("/functions/addAlternativeName", {
    method: "POST",
    body: JSON.stringify({ product_id: productId, name }),
  });

  // Lokálně zapatchujeme cache, aby alias fungoval hned, bez re-fetch feedu.
  try {
    const domains = await ensureDomains();
    const entry = findDomainEntry(domains, hostname);
    if (entry) {
      const key = feedKey(entry.domain);
      const stored = await chrome.storage.local.get(key);
      const feed = stored[key];
      if (feed) {
        const p = feed.products.find((x) => x.id === productId);
        if (p) {
          p.alternative_names = Array.isArray(result.alternative_names)
            ? result.alternative_names
            : [...(p.alternative_names || []), name];
          const newTokens = fmpTokenize(name);
          p.alt_tokens = [...new Set([...(p.alt_tokens || []), ...newTokens])];
          await chrome.storage.local.set({ [key]: feed });
        }
      }
    }
  } catch (e) {
    console.warn("[FMP] patch cache failed:", e);
  }

  return result;
}

/* ---------------------------------------------------------- zprávy */

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    const { enabled, apiKey } = await getSettings();

    switch (msg.type) {
      /* Content script: „jsem na hostname X, máš pro mě feed?" */
      case "GET_FEED": {
        if (!enabled) return sendResponse({ tracked: false, reason: "disabled" });
        if (!apiKey) return sendResponse({ tracked: false, reason: "no_api_key" });
        try {
          const domains = await ensureDomains();
          const entry = findDomainEntry(domains, msg.hostname);
          if (!entry) return sendResponse({ tracked: false });
          const feed = await ensureFeed(entry, !!msg.force);
          return sendResponse({
            tracked: true,
            domain: entry.domain,
            label: entry.label || entry.domain,
            products: feed.products,
            count: feed.products.length,
            fetchedAt: feed.fetchedAt,
          });
        } catch (e) {
          return sendResponse({ tracked: false, error: String(e.message || e) });
        }
      }

      /* Popup: stav pro aktuální tab */
      case "GET_STATUS": {
        try {
          const { domainsCache } = await chrome.storage.local.get("domainsCache");
          const domains = domainsCache ? domainsCache.domains : [];
          const entry = msg.hostname ? findDomainEntry(domains, msg.hostname) : null;
          let feedInfo = null;
          if (entry) {
            const stored = await chrome.storage.local.get(feedKey(entry.domain));
            const feed = stored[feedKey(entry.domain)];
            if (feed) feedInfo = { count: feed.products.length, fetchedAt: feed.fetchedAt };
          }
          return sendResponse({
            enabled,
            hasApiKey: !!apiKey,
            domainsCount: domains.length,
            domainsFetchedAt: domainsCache ? domainsCache.fetchedAt : null,
            tracked: !!entry,
            domainLabel: entry ? (entry.label || entry.domain) : null,
            feed: feedInfo,
          });
        } catch (e) {
          return sendResponse({ error: String(e.message || e) });
        }
      }

      /* Popup: ruční refresh seznamu domén */
      case "REFRESH_DOMAINS": {
        try {
          const domains = await ensureDomains(true);
          return sendResponse({ ok: true, count: domains.length });
        } catch (e) {
          return sendResponse({ ok: false, error: String(e.message || e) });
        }
      }

      /* Popup: ruční refresh feedu pro doménu aktuálního tabu */
      case "REFRESH_FEED": {
        try {
          const domains = await ensureDomains();
          const entry = findDomainEntry(domains, msg.hostname);
          if (!entry) return sendResponse({ ok: false, error: "Doména není sledovaná." });
          const feed = await ensureFeed(entry, true);
          return sendResponse({ ok: true, count: feed.products.length });
        } catch (e) {
          return sendResponse({ ok: false, error: String(e.message || e) });
        }
      }

      /* Content script: přidání alternativního názvu */
      case "ADD_ALT_NAME": {
        try {
          const result = await addAlternativeName(msg.productId, msg.name, msg.hostname);
          return sendResponse({ ok: true, alternative_names: result.alternative_names });
        } catch (e) {
          return sendResponse({ ok: false, error: String(e.message || e) });
        }
      }

      /* Popup: uložení nastavení */
      case "SET_SETTINGS": {
        const patch = {};
        if ("apiKey" in msg) patch.apiKey = msg.apiKey;
        if ("appBase" in msg) patch.appBase = msg.appBase;
        if ("enabled" in msg) patch.enabled = msg.enabled;
        await chrome.storage.local.set(patch);
        return sendResponse({ ok: true });
      }

      /* Content script hlásí počet shod — jen potvrdíme */
      case "PAGE_MATCHES":
        return sendResponse({ ok: true });

      default:
        return sendResponse({ error: "unknown message: " + msg.type });
    }
  })();
  return true; // async sendResponse
});

/* --------------------------------------------- denní obnova (alarm) */

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("fmp-daily", { periodInMinutes: 360 }); // kontrola 4× denně
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== "fmp-daily") return;
  const { apiKey } = await getSettings();
  if (!apiKey) return;
  // ensureDomains si samo pohlídá, jestli už dnes bylo staženo
  try { await ensureDomains(); } catch (e) { /* offline apod. — nevadí */ }
});
